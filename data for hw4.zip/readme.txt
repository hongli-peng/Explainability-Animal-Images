1. Meta information
 - # of training images: 50,000
 - # of testing images: 5,000
 - resolution: 64x64 (RGB)
 
2. How to read the dataset.
 - Similar to widely used CIFAR-10 dataset
 - See the detail at https://github.com/songhwanjun/SELFIE
 
3. Noise Rate
 - As we tested, the noise rate was estimated at 8%.
 - See our paper for the details.

4. Label Information
  - 0: cat
  - 1: lynx
  - 2: wolf
  - 3: coyote
  - 4: cheetah
  - 5: jaguer
  - 6: chimpanzee
  - 7: orangutan
  - 8: hamster
  - 9: guinea pig
